package com.example.vyaperclone

data class ReportItem(
    val Name: String,
    val type: Int
) {



}