package com.example.vyaperclone

import android.os.Parcel
import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize
@Parcelize
@Entity(tableName = "ItemsTable")
data class ItemsEntity(
    @ColumnInfo(name = "itemName") var name: String?,
    @ColumnInfo(name = "type") var type: String?,
    @ColumnInfo(name = "itemCode") var itemCode: String?,
    @ColumnInfo(name = "sacCode") var sacCode: String?,
    @ColumnInfo(name = "salePrice") var salePrice: Long?,
    @ColumnInfo(name = "purchasePrice") var purchasePrice: Long?,
    @ColumnInfo(name = "taxRate") var taxRate: Float?,
    @ColumnInfo(name = "stock") var stock: Long?,
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    var id: Int? = null,
) : Parcelable {

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(name)
        parcel.writeString(type)
        parcel.writeString(itemCode)
        parcel.writeString(sacCode)
        parcel.writeLong(salePrice ?: 0L)
        parcel.writeLong(purchasePrice ?: 0L)
        parcel.writeFloat(taxRate ?: 0f)
        parcel.writeLong(stock ?: 0L)
        parcel.writeValue(id)
    }

    companion object {
        @JvmField
        val CREATOR = object : Parcelable.Creator<ItemsEntity> {
            override fun createFromParcel(parcel: Parcel): ItemsEntity {
                return ItemsEntity(
                    parcel.readString(),
                    parcel.readString(),
                    parcel.readString(),
                    parcel.readString(),
                    parcel.readLong(),
                    parcel.readLong(),
                    parcel.readFloat(),
                    parcel.readLong(),
                    parcel.readValue(Int::class.java.classLoader) as? Int
                )
            }

            override fun newArray(size: Int): Array<ItemsEntity?> {
                return arrayOfNulls(size)
            }
        }
    }
}
