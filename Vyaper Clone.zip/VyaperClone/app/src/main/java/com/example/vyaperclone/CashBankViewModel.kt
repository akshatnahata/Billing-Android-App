package com.example.vyaperclone

import androidx.lifecycle.ViewModel

class CashBankViewModel : ViewModel()  {


}