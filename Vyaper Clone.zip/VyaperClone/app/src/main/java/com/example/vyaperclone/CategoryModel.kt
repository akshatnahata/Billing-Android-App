package com.example.vyaperclone

data class CategoryModel(
    val categoryName: String,
    val totalAmount: Int
) {
}