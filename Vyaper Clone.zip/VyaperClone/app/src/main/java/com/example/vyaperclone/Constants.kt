package com.example.vyaperclone

class Constants {
    companion object {
        const val PURCHASE = "purchase"
        const val SALE = "sale"
        const val SALEINT = 6
        const val YOUWILLGETINT = 7
        const val YOUWILLGIVEINT = 8
        const val PURCHASEINT = 9
        const val PRODUCT = "product"
        const val SERVICE = "service"
    }
}