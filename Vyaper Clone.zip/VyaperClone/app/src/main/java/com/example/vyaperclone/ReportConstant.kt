package com.example.vyaperclone

class ReportConstant {
    companion object {
        const val HEADING = 10
        const val ITEM = 11
    }
}