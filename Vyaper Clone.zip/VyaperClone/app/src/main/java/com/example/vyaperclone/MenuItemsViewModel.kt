package com.example.vyaperclone

import androidx.lifecycle.ViewModel

class MenuItemsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}