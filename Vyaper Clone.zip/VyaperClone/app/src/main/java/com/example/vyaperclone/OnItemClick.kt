package com.example.vyaperclone

interface OnItemClick {

    fun onClickShare(itemsEntity: ItemsEntity)
    fun onEditClick(itemsEntity: ItemsEntity)
}