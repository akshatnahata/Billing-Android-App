package com.example.vyaperclone

import android.view.View
import androidx.recyclerview.widget.RecyclerView

class ServicesViewHolder (itemView: View) : RecyclerView.ViewHolder(itemView) {
    fun setData(){
        itemView.apply {

        }
    }
}