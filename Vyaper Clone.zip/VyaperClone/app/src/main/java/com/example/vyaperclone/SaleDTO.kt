package com.example.vyaperclone

data class SaleDTO(
    val productName: String,
    val quantity: Int,
    val price: Long
) {

}