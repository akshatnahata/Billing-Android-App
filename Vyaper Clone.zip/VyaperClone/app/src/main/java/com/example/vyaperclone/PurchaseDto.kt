package com.example.vyaperclone

data class PurchaseDto(
    val productName: String,
    val quantity: Int,
    val price: Long
) {
}